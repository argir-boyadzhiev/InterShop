#include "Shop.hpp"
#include "PropertyList.h"
#include "Property.h"
#include "HelpFunctions.hpp"

int main() {

	Shop s;

	s.startMenu();

	return 0;
}